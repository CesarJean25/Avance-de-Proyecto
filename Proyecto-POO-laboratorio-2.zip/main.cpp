//PRINCIPAL
#include <iostream>
#include "funciones.h"

using namespace std;

// SOURCE: https://bit.ly/2NUqRgd
int getch()
{
  struct termios oldt, newt;
  int ch;
  tcgetattr(STDIN_FILENO, &oldt);
  newt= oldt;
  newt.c_lflag &= ~(ICANON| ECHO);
  tcsetattr(STDIN_FILENO, TCSANOW, &newt);
  ch = cin.get(); //ch= getchar();
  tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
  return ch;
}

int main() {
  int m = 20;
  int n = 30; 
  char direccion; 
  bool c = true; 
  

  string **arreglo = matriz(m, n);

  pollito_t p1{1, "Paco"};
  p1.posicion(arreglo, m, n);

  //nivel1(arreglo, m, n);
  nivel2(arreglo, m, n);
  
  while(c == true){
    for (int i = 0; i < m; i++){
      for (int j = 0; j < n; j++)
        cout << arreglo[i][j];
      cout << endl;
    }
  
  //cout << "x: "; 
  direccion=getch();
  //cin >> direccion;
  p1.mover(arreglo, m, n, direccion);
  system("clear");
  }
  
  
}
