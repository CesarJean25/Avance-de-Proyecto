#include "funciones.h"

string **matriz(int m, int n){

  string **arreglo = new string*[m];
  for (int i = 0; i < m; i++)
    arreglo[i] = new string[n];

  for (int i = 0; i < m; i++){
    for(int j = 0; j < n ; j++){
      if(i == 0 or j == 0 or i == m - 1 or j == n - 1 )
        arreglo[i][j] = "📔 ";
      else
        arreglo[i][j] = "  ";
    }
  }
  return arreglo;
}

void nivel1(string **matriz, int m, int n){
  
  for (int i = 0; i < m; i++){
    for(int j = 0; j < n ; j++){
      if(i == 16 and (j >= 1 and j <= 8))
        matriz[i][j] = "📔 ";
      if((i <= 16 and i >= 13) and j == 8)
        matriz[i][j] = "📔 ";
      if(i == 16 and (j >= 1 and j <= 8)) 
        matriz[i][j] = "📔 ";
      if((i <= 16 and i >= 13) and j == 8)
        matriz[i][j] = "📔 ";
    }
  }
}


void nivel2(string **matriz, int m, int n){
  //movimientos limitados
  for (int i = 0; i < m; i++){
    for(int j = 0; j < n ; j++){
      if(j == 16 and (i >= 4 and i <= 9)  )
        matriz[i][j] = "📔 "; 
      if(j == 2 and (i >= 1 and i <= 3)  )
        matriz[i][j] = "📔 "; 
      if(j == n-5 and (i >= 1 and i <= 2)  )
        matriz[i][j] = "📔 "; 
      if(j == n-3 and (i >= 2 and i <= 5)  )
        matriz[i][j] = "📔 "; 
      if(j == 16 and (i >= 4 and i <= 9)  )
        matriz[i][j] = "📔 "; 
      if((j <= 4 and j >= 2) and i == 6)
        matriz[i][j] = "📔 ";
      if((j <= 8 and j >= 2) and i == 4)
        matriz[i][j] = "📔 ";
      if((i <= 11 and i >= 7) and j == 4)
        matriz[i][j] = "📔 ";
      if((i <= 13 and i >= 6) and j == 6)
        matriz[i][j] = "📔 ";
      if((j <= 12 and j >= 3) and i == 13)
        matriz[i][j] = "📔 ";
      if((i < 18 and i >= 6) and j == 2)
        matriz[i][j] = "📔 ";
      if((15 <= 19 and i >= 15) and j == 4)
        matriz[i][j] = "📔 ";
      if((j <= 9 and j >= 4) and i == 15)
        matriz[i][j] = "📔 ";
      if((i <= 19 and i >= 17) and (j == 7) )
        matriz[i][j] = "📔 ";
      if((i==17 and j==6) or (i==3 and j==22) or (i==5 and j==24) or (i==6 and j==25))
        matriz[i][j] = "📔 ";
      if(((i <= 17 and i >= 16) and j == 9) or ((i <= 18 and i >= 14) and j == 11) )
        matriz[i][j] = "📔 ";
      if((j <= 24 and j >= 20) and i == 2)
        matriz[i][j] = "📔 ";
      if((j <= 27 and j >= 23) and i == 4)
        matriz[i][j] = "📔 ";
      
      }
  }
}

//Constructor
pollito_t::pollito_t(int vida, string nombre){
  this->vida = vida;
  this->nombre = nombre;
}

//Destructor
  
//Métodos setter
void pollito_t::set_vida(int value){
  vida = value;
}
  
void pollito_t::set_nombre(string value){
  nombre = value;
}
  
//Métodos getter
int pollito_t::get_vida(){
  return vida;
}

string pollito_t::get_nombre(){
  return nombre;
}

void pollito_t::posicion(string **matriz, int m, int n){
  for (int i = 0; i < m; i++){
    for(int j = 0; j < n ; j++){
      if(i == m-2 and j == 1)
        matriz[i][j] = "🐔 ";}
  }
}

void pollito_t::mover(string **matriz, int m, int n, char d){
  int pos_i = 0;
  int pos_j = 0;
  switch(toupper(d)){
    case 'D':
      for (int i = 0; i < m; i++){
        for(int j = 0; j < n ; j++){
          if(matriz[i][j] == "🐔 "){
            pos_i = i; 
            pos_j = j;
            }
        }
      }
      if(matriz[pos_i][pos_j+1]=="📔 ")
        matriz[pos_i][pos_j+1] = "📔 ";
      else{
        matriz[pos_i][pos_j] = "  ";
        matriz[pos_i][pos_j + 1] = "🐔 ";
      }
      break;
    
    case 'A':
      for (int i = 0; i < m; i++){
        for(int j = 0; j < n ; j++){
          if(matriz[i][j] == "🐔 "){
            pos_i = i; 
            pos_j = j;
            }
        }
      }
      if(matriz[pos_i][pos_j-1]=="📔 ")
        matriz[pos_i][pos_j-1] = "📔 ";
      else{
        matriz[pos_i][pos_j] = "  ";
        matriz[pos_i][pos_j - 1] = "🐔 ";
      }
      break;
    
    case 'S':
      for (int i = 0; i < m; i++){
        for(int j = 0; j < n ; j++){
          if(matriz[i][j] == "🐔 "){
            pos_i = i; 
            pos_j = j;
            }
        }
      }
      if(matriz[pos_i+1][pos_j]=="📔 ")
        matriz[pos_i+1][pos_j] = "📔 ";
      else{
        matriz[pos_i][pos_j] = "  ";
        matriz[pos_i + 1][pos_j] = "🐔 ";
      }
      break;
    
    case 'W':
      for (int i = 0; i < m; i++){
        for(int j = 0; j < n ; j++){
          if(matriz[i][j] == "🐔 "){
            pos_i = i; 
            pos_j = j;
            }
        }
      }
      if(matriz[pos_i-1][pos_j]=="📔 ")
        matriz[pos_i-1][pos_j] = "📔 ";
      else{
        matriz[pos_i][pos_j] = "  ";
        matriz[pos_i - 1][pos_j] = "🐔 ";
      }
      break;
  }
}




