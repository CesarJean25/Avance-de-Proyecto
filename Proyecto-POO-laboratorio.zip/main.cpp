#include <iostream>
#include "funciones.h"

using namespace std;

int main() {
  int m = 15;
  int n = 25; 
  char direccion; 
  bool c = true; 
  
  string **arreglo = matriz(m, n);

  pollito_t p1(1, "Paco");
  p1.posicion(arreglo, m, n);
  
  while(c == true){
    for (int i = 0; i < m; i++){
      for (int j = 0; j < n; j++)
        cout << arreglo[i][j];
      cout << endl;
    
  }
  
  //cout << "x: "; 
  cin >> direccion;
  p1.mover(arreglo, m, n, direccion);
  system("clear");
  }
  
  
}
