#include "funciones.h"

string **matriz(int m, int n){

  string **arreglo = new string*[m];
  for (int i = 0; i < m; i++)
    arreglo[i] = new string[n];

  for (int i = 0; i < m; i++){
    for(int j = 0; j < n ; j++){
      if(i == 0 or j == 0 or i == m - 1 or j == n - 1)
        arreglo[i][j] = "📔 ";
      else
        arreglo[i][j] = "  ";
    }
  }
  return arreglo;
}

//Constructor
pollito_t::pollito_t(int vida, string nombre){
  this->vida = vida;
  this->nombre = nombre;
}

//Destructor
  
//Métodos setter
void pollito_t::set_vida(int value){
  vida = value;
}
  
void pollito_t::set_nombre(string value){
  nombre = value;
}
  
//Métodos getter
int pollito_t::get_vida(){
  return vida;
}

string pollito_t::get_nombre(){
  return nombre;
}

void pollito_t::posicion(string **matriz, int m, int n){
  for (int i = 0; i < m; i++){
    for(int j = 0; j < n ; j++){
      if(i == m-2 and j == 1)
        matriz[i][j] = "🐔 ";}
  }
}

void pollito_t::mover(string **matriz, int m, int n, char d){
  int pos_i = 0;
  int pos_j;
  switch(toupper(d)){
    case 'D':
      for (int i = 0; i < m; i++){
        for(int j = 0; j < n ; j++){
          if(matriz[i][j] == "🐔 "){
            pos_i = i; 
            pos_j = j;
            }
        }
      }
      if(matriz[pos_i][pos_j+1]=="📔 ")
        matriz[pos_i][pos_j+1] = "📔 ";
      else{
        matriz[pos_i][pos_j] = "  ";
        matriz[pos_i][pos_j + 1] = "🐔 ";
      }
      break;
    
    case 'A':
      for (int i = 0; i < m; i++){
        for(int j = 0; j < n ; j++){
          if(matriz[i][j] == "🐔 "){
            pos_i = i; 
            pos_j = j;
            }
        }
      }
      if(matriz[pos_i][pos_j-1]=="📔 ")
        matriz[pos_i][pos_j-1] = "📔 ";
      else{
        matriz[pos_i][pos_j] = "  ";
        matriz[pos_i][pos_j - 1] = "🐔 ";
      }
      break;
    
    case 'S':
      for (int i = 0; i < m; i++){
        for(int j = 0; j < n ; j++){
          if(matriz[i][j] == "🐔 "){
            pos_i = i; 
            pos_j = j;
            }
        }
      }
      if(matriz[pos_i+1][pos_j]=="📔 ")
        matriz[pos_i+1][pos_j] = "📔 ";
      else{
        matriz[pos_i][pos_j] = "  ";
        matriz[pos_i + 1][pos_j] = "🐔 ";
      }
      break;
    
    case 'W':
      for (int i = 0; i < m; i++){
        for(int j = 0; j < n ; j++){
          if(matriz[i][j] == "🐔 "){
            pos_i = i; 
            pos_j = j;
            }
        }
      }
      if(matriz[pos_i-1][pos_j]=="📔 ")
        matriz[pos_i-1][pos_j] = "📔 ";
      else{
        matriz[pos_i][pos_j] = "  ";
        matriz[pos_i - 1][pos_j] = "🐔 ";
      }
      break;
  }
}



