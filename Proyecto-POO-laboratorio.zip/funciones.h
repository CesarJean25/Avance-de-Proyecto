#ifndef FUNCIONES_H
#define FUNCIONES_H

#include <iostream>
#include <string>
#include <vector>       
#include<cstdio>
#include<cstdlib>

using namespace std;

string **matriz(int m, int n);
 
class pollito_t{
  int vida = 0;
  string nombre;
public:
  //Constructor
  pollito_t();
  pollito_t(int vida, string nombre);
  //Destructor
  virtual ~pollito_t() = default;
  //Métodos setter
  void set_vida(int value);
  void set_nombre(string value);
  //Métodos getter
  int get_vida(); 
  string get_nombre();
  //Método mover
  void posicion(string **matriz, int m, int n);
  void mover(string **matriz, int m, int n, char direccion);
};



/*
class enemigo_t{
private:
  int salud = 0;
  int daño = 0;
  int armadura = 0;
public:
  //Constructor
  enemigo_t() = default;
  enemigo_t(int salud, int daño, int armadura): salud{salud}, daño{daño}, armadura{armadura} {}
  //Destructor
  virtual ~enemigo_t() = default;
  //Getters
  int get_salud() {return salud;}
  int get_daño() {return daño;}
  int get_armadura() {return armadura;}
  //Métodos setter
  void set_salud(int value) {salud = value;}
  void set_daño(int value) {daño = value;}
  void set_armadura(int value) {armadura = value;}
  //Métodos getter
  int danio_enemigo();
  int armadura_enemigo();

};*/

#endif